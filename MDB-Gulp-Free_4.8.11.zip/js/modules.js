exports.modules = [
  './js/_intro-mdb-free.js',
  './js/vendor/jquery.easing.js',
  './js/vendor/velocity.js',
  './js/vendor/chart.js',
  './js/vendor/wow.js',
  './js/dist/scrolling-navbar.js',
  './js/vendor/waves.js',
  './js/dist/forms-free.js',
  './js/vendor/enhanced-modals.js',
  './js/dist/treeview.js',
  './js/vendor/bs-custom-file-input.js'
  // './js/vendor/addons/jquery.zmd.hierarchical-display.js/'
  // './js/vendor/addons/masonry.pkgd.min.js',
  // './js/vendor/addons/imagesloaded.pkgd.min.js'
  // './js/vendor/addons/datatables.js'
  // './js/vendor/addons/rating.js'
  // './js/vendor/addons/progressBar.js'
];
